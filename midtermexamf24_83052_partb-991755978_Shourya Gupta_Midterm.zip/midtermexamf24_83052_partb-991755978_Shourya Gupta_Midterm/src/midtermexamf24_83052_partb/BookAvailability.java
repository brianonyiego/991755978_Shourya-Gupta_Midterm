/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package midtermexamf24_83052_partb;

/**
 * Class responsible for handling book availability status.
 * Follows Single Responsibility Principle by focusing on availability.
 * Additional functionalities like book selection are handled by BookSelector class.
 * @author causticsoda07
 */
public class BookAvailability {

    private boolean[] bookAvailability;

    // Constructor to initialize the availability array
    public BookAvailability(boolean[] bookAvailability) {
        this.bookAvailability = bookAvailability;
    }

    // Method to check if a book is available
    public boolean isAvailable(int index) {
        if (index < 0 || index >= bookAvailability.length) {
            return false; // Invalid index
        }
        return bookAvailability[index];
    }

    // Method to mark a book as borrowed
    public void borrowBook(int index) {
        if (index >= 0 && index < bookAvailability.length) {
            bookAvailability[index] = false; // Mark as unavailable
        }
    }
}

/**
 * Class responsible for selecting a book.
 * Uses BookAvailability to check if a book can be selected.
 * Follows Single Responsibility Principle by focusing on selection logic.
 * Open-Closed Principle: New selection criteria can be added without modifying this class.
 */
class BookSelector {

    private BookAvailability bookAvailability;

    // Constructor to initialize BookAvailability dependency
    public BookSelector(BookAvailability bookAvailability) {
        this.bookAvailability = bookAvailability;
    }

    // Method to select a book if it's available
    public boolean selectBook(int index) {
        if (bookAvailability.isAvailable(index)) {
            bookAvailability.borrowBook(index); // Mark book as borrowed
            return true; // Selection successful
        }
        return false; // Book is unavailable
    }
}
